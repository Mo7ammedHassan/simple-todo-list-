export function getIdFromUrl (url:string):number{
    if(url===""){
        return -1;
    }
    let partsOfUrl= url.split("/");
    let id=partsOfUrl[partsOfUrl.length-1];
    return +id;
}