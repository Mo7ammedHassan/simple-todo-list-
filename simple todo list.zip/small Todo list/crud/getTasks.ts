import { ServerResponse } from "http";
import {Tasks} from "../data/data";
export function getAllTasks(res:ServerResponse){
    res.end(JSON.stringify(Tasks));
}