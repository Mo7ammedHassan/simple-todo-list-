import { IncomingMessage, ServerResponse } from "http";
import { getIdFromUrl } from "../functions/get-id-from-url";
import {Tasks} from "../data/data";
import { pageNotFound } from "../functions/page-not-found";
import { writeFileSync } from "fs";


function deleteElementById(req:IncomingMessage,res:ServerResponse){
    let id =getIdFromUrl(req.url??"");
    if(id!==-1){
    let index = Tasks.findIndex((i)=>i.id===id);
    if (index!==-1){
    Tasks.splice(index,1);
    writeFileSync("./data/data.json",JSON.stringify(Tasks,null,1));
    res.end();
    }
    else {
        pageNotFound(res);
    }
    }
    else {
       pageNotFound(res);
    }
}
export default deleteElementById;