import { IncomingMessage, ServerResponse } from "http";
import Todo from "../types/todo";
import {Tasks} from "../data/data";
import fs from "fs"
export function createNewTask(i:number,req:IncomingMessage,res:ServerResponse){
                let data="";
           req.on("data",(chunk:any)=>
           {
            data+=chunk;
           })
           req.on("end",()=>{
            const newTask:Todo=JSON.parse(data);
            newTask.id=i;
            Tasks.push(newTask);
            fs.writeFileSync("./data/data.json",JSON.stringify(Tasks));
            res.end(JSON.stringify(newTask));
           });
        }
