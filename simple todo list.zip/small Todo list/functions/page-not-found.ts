import { IncomingMessage, ServerResponse } from "http";

export function pageNotFound(res:ServerResponse){
    res.statusCode=404;
    res.end("Not Found page");
}