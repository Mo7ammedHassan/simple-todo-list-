import { IncomingMessage, ServerResponse } from "http";
import { getIdFromUrl } from "../functions/get-id-from-url";
import {Tasks} from "../data/data";
import { pageNotFound } from "../functions/page-not-found";
import { writeFileSync } from "fs";
import Todo from "../types/todo";

function  updateElementByID(req:IncomingMessage,res:ServerResponse)
{
    
            let id =getIdFromUrl(req.url??"");
            if(id!==-1){
            let task=Tasks.find((i)=>i.id==id);
            console.log(task);
            if(task){
            let updateData:any ="";
            req.on("data",(chunk)=>{
            updateData+=chunk;
            });
            req.on("end",()=>{
            updateData= JSON.parse(updateData) as Todo;
            task.completed=updateData.id;
            task.title=updateData.title;
            writeFileSync("./data/data.json",JSON.stringify(Tasks,null,1));
            res.end();
            })
        }
        else {
            pageNotFound(res);
        }
    }
    else {
        pageNotFound(res);
    }
}
export default updateElementByID;