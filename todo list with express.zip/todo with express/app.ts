import express, { Request } from "express";
import { Tasks } from "./data/data";
import Todo from "./types/todo";
import { writeFileSync } from "fs";
const app = express();

app.use(express.json())

app.get("/api/todo", (req: Request<{}, {}, {}, { search: string }>, res) => {
    if (req.query.search) {
        let searchedTasks = Tasks.filter((i) => {
            if (i.title.toLowerCase().includes(req.query.search.toLowerCase()))
                return true;
            else return false;
        });
        res.json(searchedTasks);
        return;
    }
    else {
        res.status(200).json(Tasks);
        return;
    }
});

app.get("/api/todo/:id", (req, res) => {
    let id = +req.params.id;
    let task = Tasks.find((i) => i.id == id);
    if (task) {
        res.sendStatus(200).json(task);
    }
    else {
        res.status(404).json("Not found")
    }
});


app.post("/api/todo", (req: Request<{ id: number; tittle: string; completed: boolean }, {}, Todo>, res) => {

    console.log(req.body instanceof Object, req.body);

    if (!(req.body instanceof Object)) {
        res.status(400).json("invalid data");
    }
    else {
        let newtTask: Todo = req.body;
        Tasks.push(newtTask);
        writeFileSync("./data/data.json", JSON.stringify(Tasks));
        res.status(200).json(newtTask);
    }
});


app.put("/api/todo/:id", (req: Request<{ id: number; tittle: string; completed: boolean }, {}, Todo>, res) => {


    if (!(req.body instanceof Object)) {
        res.status(400).json("invalid data");
    }
    else {
        if (isNaN(req.body.id)) {
            let index = Tasks.findIndex((i) => i.id === req.body.id);
            Tasks[index] = { ...Tasks[index], ...req.body };
        }
        else {
            res.status(404).json("Page Not found");
        }
    }
}
);
app.delete("/api/todo/:id", (req, res) => {
    let id = req.body.id;
    if (isNaN(id)) {
        res.status(404).json("Page Not Found");
        return;
    }
    else {
        let index = Tasks.findIndex((i) => i.id === req.body.id);
        Tasks.splice(index, 1);
        res.status(200).json();
    }
});



app.listen(4000, () => {
    console.log("Server is running on port 3000");
});

