import { readFileSync }  from "fs";
import Todo from "../types/todo";

export const Tasks=<Todo[]>(JSON.parse(readFileSync("./data/data.json","utf-8")));