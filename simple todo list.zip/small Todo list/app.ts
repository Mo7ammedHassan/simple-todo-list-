import { createServer, IncomingMessage, ServerResponse } from "http";
import { getAllTasks } from "./crud/getTasks";
import { createNewTask } from "./crud/create-new-task";
import getElementFromUrl from "./crud/get-element-by-id";
import updateElementByID from "./crud/update-element-by-id";
import deleteElementById from "./crud/delete-element-by-id";
let id=0;
const server =createServer((req:IncomingMessage, res:ServerResponse) => {
        res.setHeader('Content-Type', 'application/json');
        res.statusCode = 200;
        if (req.method==='GET'&&req.url==='/api/todo') {
            getAllTasks(res);
        }
        else if (req.method==='POST'&&req.url==='/api/todo') {
            ++id;
            createNewTask(id,req,res);
        }
        else if(req.method==="GET"&&req.url?.startsWith("/api/todo/"))
        {
            getElementFromUrl(req,res);
        }
        else if (req.method==="PUT"&&req.url?.startsWith("/api/todo/"))
        {
            updateElementByID(req,res);
        }
        else if (req.method==="DELETE"&&req.url?.startsWith("/api/todo/"))
        {
            deleteElementById(req,res);
        }
});

    server.listen(5000, () => {
        console.log('Hello World');
});