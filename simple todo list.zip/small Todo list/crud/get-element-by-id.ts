import { IncomingMessage, ServerResponse } from "http";
import { getIdFromUrl } from "../functions/get-id-from-url";
import {Tasks} from "../data/data";
import { pageNotFound } from "../functions/page-not-found";

function getElementFromUrl(req:IncomingMessage,res:ServerResponse){
           let id=getIdFromUrl(req.url??"");
           if(id!==-1){
           let task=Tasks.find((i)=>i.id==id);
           if(task)
           {
                res.end(JSON.stringify(task));
           }
           else 
           {
                pageNotFound(res);
           }
        }
        else{
            pageNotFound(res);
        }
}
export default getElementFromUrl;